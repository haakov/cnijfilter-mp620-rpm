#undef PACKAGE
#undef VERSION
#undef XBJLIBPATH
#undef XBINPATH
