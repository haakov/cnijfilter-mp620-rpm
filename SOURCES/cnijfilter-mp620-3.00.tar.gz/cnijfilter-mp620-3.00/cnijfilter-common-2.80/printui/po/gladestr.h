char *s = N_("  Black:");
char *s = N_("  Cyan:");
char *s = N_("  Magenta:");
char *s = N_("  Set ...  ");
char *s = N_("  Yellow:");
/* xgettext:no-c-format */
char *s = N_("% (20-400)");
char *s = N_("(1-999)");
char *s = N_("*");
char *s = N_("0");
char *s = N_("1");
char *s = N_("2");
char *s = N_("3");
char *s = N_("4");
char *s = N_("5");
char *s = N_("About");
char *s = N_("Adjustment in Columns A to C (-3 to +7)");
char *s = N_("Adjustment in Columns A to D (-3 to +7)");
char *s = N_("Adjustment in Columns A to E (-3 to +7)");
char *s = N_("Adjustment in Columns A to F (-5 to +5)");
char *s = N_("Adjustment in Columns D to F (-5 to +5)");
char *s = N_("Adjustment in Columns E to G (-5 to +5)");
char *s = N_("Adjustment in Columns F to K (-5 to +5)");
char *s = N_("Adjustment in Columns G to J (-5 to +5)");
char *s = N_("Adjustment in Columns G to L (-5 to +5)");
char *s = N_("Adjustment in Columns H to K (-5 to +5)");
char *s = N_("Adjustment in Columns K and L (-3 to +3)");
char *s = N_("Adjustment in Columns L and M (-3 to +3)");
char *s = N_("Adjustment in Columns L to O (-5 to +5)");
char *s = N_("Adjustment in Columns M and N (-2 to +2)");
char *s = N_("Adjustment in Columns M to P (-2 to +2)");
char *s = N_("Adjustment in Columns P to T (-5 to +5)");
char *s = N_("Adjustment in Columns Q and R (-4 to +4)");
char *s = N_("Adjustment in Columns U and V (-3 to +3)");
char *s = N_("Adjustment in Columns a to e (-2 to +2)");
char *s = N_("Adjustment in Columns f to k (-2 to +2)");
char *s = N_("Align heads manually");
char *s = N_("All Colors");
char *s = N_("Amount of Extension:");
char *s = N_("Auto");
char *s = N_("Auto Power");
char *s = N_("Auto Power Off");
char *s = N_("Auto Power Off:");
char *s = N_("Auto Power On:");
char *s = N_("Auto Power Settings");
char *s = N_("Automatic Duplex Printing");
char *s = N_("Available Media Types:");
char *s = N_("BJ Cartridge:");
char *s = N_("Back to Setup");
char *s = N_("Bi-directional Alignment (-5 to +5)");
char *s = N_("Black");
char *s = N_("Black Ink Tank");
char *s = N_("Borderless Printing");
char *s = N_("Bottom Plate Cleaning");
char *s = N_("Brightness:");
char *s = N_("Cancel");
char *s = N_("Canon Inkjet Printer Driver Ver.2.80 for Linux\n"
             "Copyright CANON INC. 2001-2007\n"
             "All Rights Reserved. ");
char *s = N_("Centering");
char *s = N_("Change");
char *s = N_("Change Combination");
char *s = N_("Change Media Type");
char *s = N_("Changing the Paper Source ");
char *s = N_("Cleaning");
char *s = N_("Click Change to use this, or Back to Setup to select a different combination.");
char *s = N_("Collate");
char *s = N_("Color");
char *s = N_("Color Balance");
char *s = N_("Color Ink Tank");
char *s = N_("Color Mode:");
char *s = N_("Color/Intensity:");
char *s = N_("Column A:");
char *s = N_("Column B:");
char *s = N_("Column C:");
char *s = N_("Column D:");
char *s = N_("Column E:");
char *s = N_("Column F:");
char *s = N_("Column G:");
char *s = N_("Column H:");
char *s = N_("Column I:");
char *s = N_("Column J:");
char *s = N_("Column K:");
char *s = N_("Column L:");
char *s = N_("Column M:");
char *s = N_("Column N:");
char *s = N_("Column O:");
char *s = N_("Column P:");
char *s = N_("Column Q:");
char *s = N_("Column R:");
char *s = N_("Column S:");
char *s = N_("Column T:");
char *s = N_("Column U:");
char *s = N_("Column V:");
char *s = N_("Column a:");
char *s = N_("Column b:");
char *s = N_("Column c:");
char *s = N_("Column d:");
char *s = N_("Column e:");
char *s = N_("Column f:");
char *s = N_("Column g:");
char *s = N_("Column h:");
char *s = N_("Column i:");
char *s = N_("Column j:");
char *s = N_("Column k:");
char *s = N_("Contrast:");
char *s = N_("Copies:");
char *s = N_("Custom");
char *s = N_("Custom Paper Size");
char *s = N_("Custom Settings");
char *s = N_("Dark ");
char *s = N_("Deep Cleaning");
char *s = N_("Deep Cleaning requires a lot of ink. Execute it only when you have not resolved the print head problem by trying cleaning several times.\n"
             "\n"
             "Select the print head for deep cleaning.");
char *s = N_("Defaults");
char *s = N_("Diffusion");
char *s = N_("Display low ink warning");
char *s = N_("Dither");
char *s = N_("Examine the printed patterns, and enter the pattern number of the most \n"
             "even pattern for columns M and N.");
char *s = N_("Examine the printed patterns, and enter the pattern number of the pattern \n"
             "with the least amount of streaking in the fields for columns G to L.");
char *s = N_("Examine the printed patterns, and enter the pattern number of the pattern \n"
             "with the least amount of streaking in the fields for columns H to O.");
char *s = N_("Examine the printed patterns, and enter the pattern number of the pattern \n"
             "with the least amount of streaking in the fields for columns M to R.");
char *s = N_("Examine the printed patterns, and enter the pattern number of the pattern \n"
             "with the least amount of streaking in the fields for columns P to V.");
char *s = N_("Examine the printed patterns, and enter the pattern number of the pattern \n"
             "with the least noticeable horizontal stripes in the fields for columns a to k.");
char *s = N_("Examine the printed patterns, and fill in the fields for columns L and M with \n"
             "the number of the pattern that is smoothest and has no stripes in the areas \n"
             "indicated by arrows.");
char *s = N_("Execute");
char *s = N_("Execute print head alignment. Examine the printed patterns, and enter \n"
             "the pattern number of the pattern with the least amount of streaking in \n"
             "the fields for columns A to F.");
char *s = N_("Execute print head alignment. Examine the printed patterns, and enter \n"
             "the pattern number of the pattern with the least amount of streaking in \n"
             "the fields for columns A to G.");
char *s = N_("Execute print head alignment. Examine the printed patterns, and enter \n"
             "the pattern number of the pattern with the least amount of streaking in \n"
             "the fields for columns A to K.");
char *s = N_("Execute print head alignment. Examine the printed patterns, and enter \n"
             "the pattern number of the pattern with the least amount of streaking in the \n"
             "fields for columns A to L.");
char *s = N_("Executes Bottom Plate Cleaning.\n"
             "\n"
             "1. Remove the paper from the sheet feeder.\n"
             "2. Fold A4 or letter size, plain paper in half. Unfold the paper, and load the paper into \n"
             "the sheet feeder with the ridge of the crease facing down. Then click Execute.");
char *s = N_("Exit");
char *s = N_("Fast");
char *s = N_("Fine");
char *s = N_("Grayscale Printing");
char *s = N_("Halftoning:");
char *s = N_("Height:     ");
char *s = N_("High");
char *s = N_("High ");
char *s = N_("Horizontal Alignment (-3 to +7)");
char *s = N_("If the printed pattern resembles this pattern, \n"
             "the print head nozzles may be clogged.\n"
             "Click Cleaning.\n"
             "\n"
             "If the printed pattern does not improve, \n"
             "even after Cleaning is executed two times, \n"
             "execute Deep Cleaning.");
char *s = N_("Ignore");
char *s = N_("Ink Cartridge Settings");
char *s = N_("Ink Cartridge:");
char *s = N_("Ink Counter Reset");
char *s = N_("Ink Drying Wait Time:");
char *s = N_("Intensity:");
char *s = N_("Light ");
char *s = N_("Long");
char *s = N_("Long-side stapling");
char *s = N_("Low");
char *s = N_("Low Ink Warning Setting");
char *s = N_("Main");
char *s = N_("Maintenance");
char *s = N_("Manual");
char *s = N_("Manual Color Adjustment");
char *s = N_("Max");
char *s = N_("Media Type:");
char *s = N_("Min");
char *s = N_("Nozzle Check");
char *s = N_("OK");
char *s = N_("Page Layout:");
char *s = N_("Page Setup");
char *s = N_("Page Size:");
char *s = N_("Paper Gap:");
char *s = N_("Paper Size");
char *s = N_("Paper Source:");
char *s = N_("Pattern Check");
char *s = N_("Pause Page");
char *s = N_("Pause Scan");
char *s = N_("Power Off");
char *s = N_("Prevent paper abrasion");
char *s = N_("Print Alignment Value");
char *s = N_("Print Check Pattern");
char *s = N_("Print Head Alignment");
char *s = N_("Print Head Cleaning");
char *s = N_("Print Head:");
char *s = N_("Print Quality:");
char *s = N_("Print Type:");
char *s = N_("Print from Last Page");
char *s = N_("Quality:");
char *s = N_("Quiet Mode");
char *s = N_("Read your printer manual for details about low ink warnings.");
char *s = N_("Roller Cleaning");
char *s = N_("Scaling:");
char *s = N_("Select print head for cleaning.");
char *s = N_("Select the ink cartridge for printing.");
char *s = N_("Select the newly replaced ink tank and click the Execute button.\n"
             "");
char *s = N_("Send");
char *s = N_("Short");
char *s = N_("Short-side stapling");
char *s = N_("Standard");
char *s = N_("Staple Side:");
char *s = N_("Start Print Head Alignment");
char *s = N_("Starting Bottom Plate Cleaning to prevent paper smudges during printing.\n"
             "\n"
             "This operation needs a sheet of A4 or letter size, plain paper. Follow these directions to execute Bottom Plate Cleaning.");
char *s = N_("The counter corresponding to the replaced ink tank will indicate \n"
             "the tank is full. This operation ensures proper display of a low \n"
             "ink warning.");
char *s = N_("The following is recommended:");
char *s = N_("The print head nozzles are not clogged.\n"
             "If the printed pattern resembles this pattern, you can \n"
             "use the printer immediately.\n"
             "Click Exit.\n"
             "");
char *s = N_("To ensure proper display of a low ink warning, the following operation is \n"
             "required:\n"
             "");
char *s = N_("Unclogs nozzles that cannot be cleared by regular cleaning.\n"
             "\n"
             "Deep cleaning consumes much more ink than regular cleaning. Execute Deep \n"
             "Cleaning only if the nozzle condition does not improve after regular cleaning.\n"
             "\n"
             "After the deep cleaning ends, execute Nozzle Check and check whether the \n"
             "print head nozzles have been unclogged.");
char *s = N_("Units:");
char *s = N_("Use quiet mode");
char *s = N_("Using AC Adapter:");
char *s = N_("Using Battery:");
char *s = N_("View Printer Status...");
char *s = N_("Vivid Photo");
char *s = N_("When you have replaced an ink tank with a new one, always click \n"
             "the Ink Counter Reset button on the Maintenance tab of the printer driver \n"
             "and select the new ink tank.");
char *s = N_("Which of the following patterns does the printed pattern most closely resemble?");
char *s = N_("Width:    ");
char *s = N_("You cannot print with the following combination:");
char *s = N_("You have selected the following combination:");
char *s = N_("inch");
char *s = N_("mm");
